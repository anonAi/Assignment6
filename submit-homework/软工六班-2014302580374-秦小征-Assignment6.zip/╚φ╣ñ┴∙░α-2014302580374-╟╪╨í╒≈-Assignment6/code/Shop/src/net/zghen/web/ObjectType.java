package net.zghen.web;
import java.util.ArrayList;  

public class ObjectType {  
  
    private String type;  
    private ArrayList<Anim> subObjects;  
    public String getType() {  
        return type;  
    }  
    public void setType(String type) {  
        this.type = type;  
    }  
    public ArrayList<Anim> getSubObjects() {  
        return subObjects;  
    }  
    public void setSubObjects(ArrayList<Anim> subObjects) {  
        this.subObjects = subObjects;  
    }   
}  