package net.zghen.web;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

public class util {
	private static Connection getConn() {
	    String driver = "com.mysql.jdbc.Driver";
		 String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	    Connection conn = null;
	    try {
	        Class.forName(driver); //classLoader,���ض�Ӧ����
			conn = DriverManager.getConnection(url);
	    } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return conn;
	}
	public static int hasSignIn(String username, String token) throws SQLException{
		int back = -1;
		Connection conn = getConn();
		String sql = "select * from 2014302580374_user";
		PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        int i = 0;
	        while(rs.next()){
	        	//data.put(i, rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        //	System.out.println(rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        	if(rs.getString("username").equals(username)){
	        		back = 0;
	        		if(rs.getString("token").equals(token)){
		        		if(rs.getInt("hasSignIn") == 1)
		        			back = 1;
		        		else
		        			back = 0;
		        		break;
	        		}
	        	}
	        	i++;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    conn.close();
		return back;
	}
	public static int auth(String username, String password) throws SQLException{
		int back = -1;
		Connection conn = getConn();
		String sql = "select * from 2014302580374_user";
		PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        int i = 0;
	        while(rs.next()){
	        	//data.put(i, rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        //	System.out.println(rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        	if(rs.getString("username").equals(username) && rs.getString("password").equals(password)){
	        		back = 1;
	        		break;
	        	}
	        	i++;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    conn.close();
		return back;
	}
	public static int signIn(String username, String password, String token) throws SQLException{
		if(hasSignIn(username, token) == 1){
			return 0;
		}
		if(auth(username, password) == -1){
			return -1;
		}
	    Connection conn = getConn();
	    int i = 0;
	    String sql = "update 2014302580374_user set hasSignIn = 1 where username ='" + username + "'";
	    String sql2 =  "update 2014302580374_user set token = '" + token + "' where username ='" + username + "'";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        i = pstmt.executeUpdate();
	        
	        System.out.println("resutl: " + i);
	        pstmt.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    try{
	    	pstmt = (PreparedStatement) conn.prepareStatement(sql2);
	    	i = pstmt.executeUpdate();
	    	System.out.println("update: " + i);
	    	pstmt.close();
	    	conn.close();
	    } catch (SQLException e){
	    	e.printStackTrace();
	    }
		return 1;
	}
	public static int signOut(String username, String token) throws SQLException{
		if(hasSignIn(username, "") == -1){ // means this username doesn't exist
			return -1;
		}
	    Connection conn = getConn();
	    int i = 0;
	    String sql = "update 2014302580374_user set hasSignIn = 0 where username ='" + username + "'";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        i = pstmt.executeUpdate();
	        
	        System.out.println("resutl: " + i);
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return 1;
	}
	public static int signUp(String username, String password) throws SQLException{
		if(hasSignIn(username, "") != -1){ // means this username has been signUp, we has the same user in our database
			return -1;
		}
	    Connection conn = getConn();
	    String sql = "insert into 2014302580374_user (username, password, token, hasSignIn, shoppingCart, money, orderForm, descInfo, otherInfo)"
	    		+ " values ('" + username + "','" + password + "',' '," + 0 + ",' ', ' ',' ',' ','0')";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return 1;
	}
	public static int addToShoppingCart(String username, String token, String anim) throws SQLException{
		if(hasSignIn(username, token) != 1){
			return -1;
		}
		int back = -1;
		Connection conn = getConn();
		String sql = "select * from 2014302580374_user";
		PreparedStatement pstmt;
		String cart = "";
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        int i = 0;
	        while(rs.next()){
	        	//data.put(i, rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        //	System.out.println(rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        	if(rs.getString("username").equals(username)){
	        		cart = rs.getString("shoppingCart");
	        		cart += anim + "$";
	        	}
	        	i++;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    String sql2 = "update 2014302580374_user set shoppingCart = '" + cart + "' where username ='" + username + "'";
	    PreparedStatement pstmt2;
	    try {
	        pstmt2 = (PreparedStatement) conn.prepareStatement(sql2);
	        pstmt2.executeUpdate();
	        pstmt2.close();
	        back = 1;
	    }catch(SQLException e){
	    	e.printStackTrace();
	    	back = 0;
	    }
	    conn.close();
	    return back;
	}
	public static int delFromShoppingCart(String username, String token, String anim) throws SQLException{
		if(hasSignIn(username, token) != 1){
			return -1;
		}
		int back = -1;
		Connection conn = getConn();
		String sql = "select * from 2014302580374_user";
		PreparedStatement pstmt;
		String cart = "";
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        int i = 0;
	        while(rs.next()){
	        	//data.put(i, rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        //	System.out.println(rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        	if(rs.getString("username").equals(username)){
	        		cart = rs.getString("shoppingCart");
	        		if(cart.indexOf(anim) == -1)
	        			back = -1;
	        		else{
	        			cart = cart.substring(0, cart.indexOf(anim)) + cart.substring(cart.indexOf(anim) + anim.length() + 1, cart.length());
	        		}
	        	}
	        	i++;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    String sql2 = "update 2014302580374_user set shoppingCart = '" + cart + "' where username ='" + username + "'";
	    PreparedStatement pstmt2;
	    try {
	        pstmt2 = (PreparedStatement) conn.prepareStatement(sql2);
	        pstmt2.executeUpdate();
	        pstmt2.close();
	        back = 1;
	    }catch(SQLException e){
	    	e.printStackTrace();
	    	back = 0;
	    }
	    conn.close();
	    return back;
	}
	public static String getShoppingCart(String username, String token) throws SQLException{
		if(hasSignIn(username, token) != 1){
			return "null";
		}
		int back = -1;
		Connection conn = getConn();
		String sql = "select * from 2014302580374_user";
		PreparedStatement pstmt;
		String cart = "";
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        int i = 0;
	        while(rs.next()){
	        	//data.put(i, rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        //	System.out.println(rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        	if(rs.getString("username").equals(username)){
	        		cart = rs.getString("shoppingCart");
	        	}
	        	i++;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    conn.close();
	    return cart;
	}
	public static Set<Anim> getAnims() throws SQLException{
		Set<Anim> anims = new HashSet<Anim>();
		Connection conn = getConn();
		String sql = "select * from pet";
		PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        int i = 0;
	        while(rs.next()){
	        	//data.put(i, rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        //	System.out.println(rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        	anims.add(new Anim(rs.getInt("id"), rs.getString("name"), rs.getString("eat"), rs.getString("drink"), rs.getString("live"), rs.getString("hobby")));
	        	i++;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    conn.close();
		return anims;
	}
}
