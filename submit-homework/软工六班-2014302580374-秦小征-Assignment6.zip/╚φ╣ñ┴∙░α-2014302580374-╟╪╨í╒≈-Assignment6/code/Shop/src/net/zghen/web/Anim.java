package net.zghen.web;

public class Anim {
	public int id;
	public String name;
	public String eat;
	public String drink;
	public String live;
	public String hobby;
	public Anim(int id, String name, String eat, String drink, String live, String hobby){
		this.id = id;
		this.name = name;
		this.eat = eat;
		this.drink = drink;
		this.live = live;
		this.hobby = hobby;
	}
}
